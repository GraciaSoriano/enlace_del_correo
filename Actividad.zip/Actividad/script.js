const nodemailer = require('nodemailer');


const transporter = nodemailer.createTransport({
  service: 'outlook',
  auth: {
    user: 'graciasoriano27.11.5@outlook.com', // Mi correo de Outlook
    pass: '********' // Mi contraseña
  }
});


const mailOptions = {
  from: 'graciasoriano27.11.5@outlook.com', // Remitente
  to: 'j.william03@hotmail.com', // Destinatario
  subject: 'Implementación de servidor de correos', // Asunto
  text: '¡Servidor de correo funcionando excelente!' // Cuerpo del correo
};


transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Correo enviado: ' + info.response);
  }
});
